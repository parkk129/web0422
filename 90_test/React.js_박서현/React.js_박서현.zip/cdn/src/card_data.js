
const cards = [
    {
        cimg: "https://ticketimage.interpark.com/Play/image/large/24/24006851_p.gif",
        ctit: "뮤지컬 〈하데스타운〉 한국 공연",
        crate: "샤롯데씨어터",
        cdate: "2024.07.12 - 2024.10.06",
    },
    {
        cimg: "https://ticketimage.interpark.com/Play/image/large/24/24007345_p.gif",
        ctit: "뮤지컬 〈베르사유의 장미〉",
        crate: "충무아트센터 대극장",
        cdate: "2024.07.16 - 2024.10.13",
    },
    {
        cimg: "https://ticketimage.interpark.com/Play/image/large/24/24010223_p.gif",
        ctit: "뮤지컬 〈킹키부츠〉",
        crate: "블루스퀘어 신한카드홀",
        cdate: "2024.09.07 - 2024.11.10",
    },
    {
        cimg: "https://ticketimage.interpark.com/Play/image/large/24/24011991_p.gif",
        ctit: "뮤지컬 〈시카고〉 - 창원",
        crate: "창원 성산아트홀 대극장",
        cdate: "2024.10.25 - 2024.10.27",
    },
];
